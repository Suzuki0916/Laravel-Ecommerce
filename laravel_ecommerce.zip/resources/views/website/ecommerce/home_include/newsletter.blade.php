<div class="newsletter-area box-shadow mt-35 bg-fff">
    <div class="product-title home3-bg text-uppercase">
        <i class="fa fa-envelope-o icon home3-bg2"></i>
        <h3>NEWSLETTER SIGN UP</h3>
    </div>
    <div class="newsletter form-style plbr-15">
        <p>Submit your mail to get events</p>
        <form action="#">
            <input type="email" placeholder="Email" />
            <button><i class="fa fa-paper-plane-o"></i></button>
        </form>
    </div>
</div>
