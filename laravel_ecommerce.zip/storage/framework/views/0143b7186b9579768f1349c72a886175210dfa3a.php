<nav>
    <ul>
        <li class="active2"><a href="/">Home</a></li>
        <li><a href="<?php echo e(route('website_products')); ?>">product</a></li>
        <li><a href="<?php echo e(route('website_details')); ?>">product details</a></li>
        <li><a href="<?php echo e(route('website_cart')); ?>">cart</a></li>
        <li><a href="<?php echo e(route('website_wishlist')); ?>">wishlist</a></li>
        <li><a href="<?php echo e(route('website_checkout')); ?>">checkout</a></li>
        <li><a class="menu-contact" href="<?php echo e(route('website_contact')); ?>">contact us</a></li>
    </ul>
</nav>
<?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/website/ecommerce/layouts/navbar.blade.php ENDPATH**/ ?>