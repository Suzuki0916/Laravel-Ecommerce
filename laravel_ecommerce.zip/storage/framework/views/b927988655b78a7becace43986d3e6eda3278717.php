<div class="logo hm3-logo">
    <a href="/">
        <img src="<?php echo e(asset('contents/website')); ?>/img/logo/1.png" alt="" />
    </a>
</div>
<?php /**PATH E:\xampp\htdocs\laravel_ecommerce\resources\views/website/ecommerce/layouts/logo.blade.php ENDPATH**/ ?>