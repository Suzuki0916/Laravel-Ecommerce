<div class="">

    <div class="select_body d-flex justify-content-between align-items-center">
        <select name="<?php echo e($name); ?><?php echo e($attributes?'[]' : ''); ?>" id="select<?php echo e($name); ?>" class="form-control <?php echo e($class); ?>" <?php echo e($attributes); ?>>
            <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($value) && !is_object($value) && !is_array($value)): ?>
                    <option <?php echo e($value == $item->id ?'selected':''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endif; ?>

                <?php if(!isset($value) || (isset($value) && $value == '')): ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endif; ?>

                <?php if(isset($value) && is_object($value)): ?>
                    <?php
                        $value_ids = [];
                        foreach ($value as $key2 => $item2) {
                            array_push($value_ids,$item2->id);
                        }
                    ?>
                    <option <?php echo e(in_array($item->id,$value_ids ) ?'selected':''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button class="btn btn-info" data-toggle="modal" data-target="#<?php echo e($name); ?>Modal" type="button" title="add new brand">
            <i class="fa fa-plus"></i>
        </button>
    </div>
    <span class="text-danger <?php echo e($name); ?>"></span>
</div>

<div class="modal fade" id="<?php echo e($name); ?>Modal"  tabindex="-1" aria-labelledby="<?php echo e($name); ?>ModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-uppercase" id="<?php echo e($name); ?>ModalLabel"><?php echo e(str_replace('_',' ',str_replace('_id','',$name))); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <forms action="<?php echo e($action); ?>" data-target_select="#select<?php echo e($name); ?>" class="component_form" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <div class="preloader component_preloader"></div>
                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $item = (object) $item;
                            ?>
                            <div class="form-group">
                                <label for=""><?php echo e($item->name); ?></label>
                                <div class="">
                                    <?php if($item->type == 'text' || $item->type == 'file' || $item->type == 'email'): ?>
                                        <input type="<?php echo e($item->type); ?>" name="<?php echo e($item->name); ?>" class="form-control"  placeholder="<?php echo e($item->name); ?>" />
                                    <?php endif; ?>

                                    <?php if($item->type == 'textarea'): ?>
                                        <textarea name="<?php echo e($item->name); ?>" class="form-control" cols="30" rows="5" placeholder="<?php echo e($item->name); ?>"></textarea>
                                    <?php endif; ?>

                                    <?php if($item->type == 'select'): ?>
                                        <div class="d-flex select_ontime justify-content-between align-items-center">
                                            <select name="<?php echo e($item->name); ?>"
                                                    data-this_field_will_contorl="<?php echo e(isset($item->this_field_will_contorl) ? $item->this_field_will_contorl: ''); ?>"
                                                    data-this_field_control_route="<?php echo e(isset($item->this_field_control_route) ? $item->this_field_control_route : ''); ?>"
                                                    class="form-control <?php echo e(isset($item->class) ?$item->class:''); ?>">
                                                <option value="">press reload btn</option>
                                            </select>
                                            <?php if($item->option_route): ?>
                                                <button type="button" class="btn btn-info load_options" data-url="<?php echo e($item->option_route); ?>"><i class="fa fa-recycle"></i></button>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>


                                    <span class="text-danger <?php echo e($item->name); ?> "></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="component_form_submit btn btn-primary">Submit</button>
                </div>
            </forms>
        </div>
    </div>
</div>

<?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/admin/product/components/select.blade.php ENDPATH**/ ?>