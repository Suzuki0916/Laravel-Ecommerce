<div class="header-top-right">
    <p class="pull-left h2-color mtb-10 d-none d-md-block">Wellcome to Oneclick store!</p>
    <div class="account-menu text-right pull-right mt-10 home3-hover">
        <ul>
            <li><a href="#">My Account</a></li>
            <li><a href="#">Checkout</a></li>
            <li><a href="#">Shopping Cart</a></li>
            <li><a href="#">Wishlist</a></li>
        </ul>
    </div>
</div>
<?php /**PATH E:\xampp\htdocs\laravel_ecommerce\resources\views/website/ecommerce/layouts/header_right_links.blade.php ENDPATH**/ ?>