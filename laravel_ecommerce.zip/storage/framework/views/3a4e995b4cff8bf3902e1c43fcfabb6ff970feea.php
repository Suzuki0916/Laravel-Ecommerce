<div class="search-box home3-search-box">
    <form action="#">
        <select name="#" id="select">
            <option value="">All categories</option>
            <option value="40">Accessories</option>
            <option value="41">Clothing</option>
            <option value="42">-Hoodies</option>
            <option value="47">-T-shirts</option>
            <option value="43">Men's</option>
            <option value="50"> -Hats</option>
            <option value="44">Music</option>
            <option value="46">-Singles</option>
            <option value="49">-Albums</option>
            <option value="45">Posters</option>
            <option value="48">Women's</option>
            <option value="51">-Hats</option>
        </select>
        <input type="text" placeholder="Search Products…" />
        <button><i class="fa fa-search"></i></button>
    </form>
</div>
<?php /**PATH E:\xampp\htdocs\laravel_ecommerce\resources\views/website/ecommerce/layouts/search.blade.php ENDPATH**/ ?>